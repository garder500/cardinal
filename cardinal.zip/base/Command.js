const path = require("path");

module.exports = class Command {
    constructor(client, {
        name = null,
        description = (" "),
        usage = (" "),
        examples = (" "),
        dirname = false,
        enabled = true,
        guildOnly = false,
        aliases = new Array(),
        botPermissions = new Array(),
        memberPermissions = new Array(),
        ownerOnly = false,
        cooldown = 3000
    }) 
    
    {
        let category = (dirname ? dirname.split(path.sep)[parseInt(dirname.split(path.sep).length - 1, 10)] : "Other");
        this.client = client;
        this.conf = { enabled, guildOnly, aliases, memberPermissions, botPermissions, ownerOnly, cooldown };
        this.help = { name, description, category, usage, examples };
    }
};
