module.exports = {
  token: "NzY5NjE0NzgxMDQzNzAzODEw.X5Rlng.RtLXx6375vCVXqE-Z0m_mfLchdE",
  ownerID: ["640302286463172628","243117191774470146"],
  botID: "782658439591231519",
  prefix: "$",
  shard: 0,
  mysql: {
    host: "sql01.hostim.fr",
    port: "3306",
    user: "3010a894_urm2ft",
    password: "jw9QIZB6vLE7y34c",
    database: "3010a894_cardinal",
  },
  embed: {
    color: "BLACK",
    footer: "Cardinale. ❤️",
    global: {
      thumbnail:"https://cdn.discordapp.com/avatars/782658439591231519/09d20a44d888dafb7f5eda3ae5c92a41.webp?size=1024",
    },
    clan: {
      thumbnail: "https://cdn.discordapp.com/attachments/640304005683216384/783304683858559016/clan_system.png",
    },
    url: "https://discord.gg/cQsAFfYtEJ",
    error: {
      thumbnail: "https://cdn.discordapp.com/attachments/640304005683216384/783306090611605574/error_system.png",
    },
  }
}; 